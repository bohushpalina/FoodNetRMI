package foodnet.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import foodnet.data.Dish;
import foodnet.data.Order;

public interface FoodService extends Remote {
    List<Dish> getMenu() throws RemoteException;
    double calculateSum(List<String> dishNames) throws RemoteException;
    void submitOrder(Order order) throws RemoteException;
}
