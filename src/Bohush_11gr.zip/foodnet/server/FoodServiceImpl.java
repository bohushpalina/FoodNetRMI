package foodnet.server;

import foodnet.data.*;
import foodnet.rmi.FoodService;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.*;

public class FoodServiceImpl extends UnicastRemoteObject implements FoodService {

    private static final List<Dish> menu = Arrays.asList(
        new Dish("Pizza", 12.5),
        new Dish("Burger", 9.0),
        new Dish("Salad", 5.0),
        new Dish("Sushi", 14.0)
    );

    public FoodServiceImpl() throws RemoteException {}

    @Override
    public List<Dish> getMenu() {
        return menu;
    }

    public double getOrderSum(List<String> dishNames) {
        double sum = 0;

        for (String dish : dishNames) {
            for (Dish d : menu) {
                if (d.getName().equalsIgnoreCase(dish.trim())) {
                    sum += d.getPrice();
                }
            }
        }
        return sum;
    }

    @Override
    public void submitOrder(Order order) {
        double sum = getOrderSum(order.getDishes()
            .stream().map(Dish::getName).toList());

        System.out.println("--- Order report ---");
        System.out.println("Dishes: " + order.getDishes());
        System.out.println("Total: " + sum);
        System.out.println("Address: " + order.getAddress());
        System.out.println("--------------------");
    }

	@Override
	public double calculateSum(List<String> dishNames) throws RemoteException {
		return getOrderSum(dishNames);
	}
}
