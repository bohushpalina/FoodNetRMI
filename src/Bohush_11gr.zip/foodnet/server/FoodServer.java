package foodnet.server;

import foodnet.rmi.FoodService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class FoodServer {
    public static void main(String[] args) throws Exception {
        FoodService service = new FoodServiceImpl();
        Registry registry = LocateRegistry.createRegistry(1099);
        registry.rebind("FoodService", service);
        System.out.println("Server started");
    }
}
